## Pcwrun.exe
* Functions: Execute
```

Pcwrun.exe c:\temp\beacon.exe
Open the target .EXE file with the Program Compatibility Wizard.
```
   
* Resources:   
  * https://twitter.com/pabraeken/status/991335019833708544
   
* Full path:   
  * c:\windows\system32\pcwrun.exe
   
* Notes: Thanks to Pierre-Alexandre Braeken - @pabraeken  
   
