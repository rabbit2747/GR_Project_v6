## Nltest.exe
* Functions: Credentials
```

nltest.exe /SERVER:192.168.1.10 /QUERY

```
   
* Resources:   
  * https://twitter.com/sysopfb/status/986799053668139009
  * https://ss64.com/nt/nltest.html
   
* Full path:   
  * c:\windows\system32\nltest.exe
   
* Notes: Thanks to Sysopfb - @sysopfb  
   
