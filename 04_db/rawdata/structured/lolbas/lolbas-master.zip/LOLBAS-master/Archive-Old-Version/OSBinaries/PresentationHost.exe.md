## PresentationHost.exe
* Functions: Execute
```

Presentationhost.exe C:\temp\Evil.xbap
Executes the target XAML Browser Application (XBAP) file.
```
   
* Resources:   
  * https://github.com/api0cradle/ShmooCon-2015/blob/master/ShmooCon-2015-Simple-WLEvasion.pdf
  * https://oddvar.moe/2017/12/21/applocker-case-study-how-insecure-is-it-really-part-2/
   
* Full path:   
  * c:\windows\system32\PresentationHost.exe     
  * c:\windows\sysWOW64\PresentationHost.exe    
   
* Notes: Thanks to Casey Smith - @subtee  
   
