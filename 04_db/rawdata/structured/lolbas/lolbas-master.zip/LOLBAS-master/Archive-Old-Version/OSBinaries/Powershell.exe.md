## Powershell.exe
* Functions: Execute, Read ADS
```

powershell -ep bypass - < c:\temp:ttt
Execute the encoded PowerShell command stored in an Alternate Data Stream (ADS).
```
   
* Resources:   
  * https://twitter.com/Moriarty_Meng/status/984380793383370752
   
* Full path:   
  * C:\Windows\SysWOW64\WindowsPowerShell\v1.0\powershell.exe
  * C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe
   
* Notes: Thanks to Moriarty - @Moriarty_Meng  
   
