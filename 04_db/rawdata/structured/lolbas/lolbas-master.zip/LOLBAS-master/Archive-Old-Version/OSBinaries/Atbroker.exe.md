## Atbroker.exe
* Functions: Execute
```

ATBroker.exe /start malware
Start a registered Assistive Technology (AT).
```
   
* Resources:   
  * http://www.hexacorn.com/blog/2016/07/22/beyond-good-ol-run-key-part-42/
   
* Full path:   
  * C:\Windows\System32\Atbroker.exe
  * C:\Windows\SysWOW64\Atbroker.exe
   
* Notes: Thanks to Adam - @hexacorn Modifications must be made to the system registry to either register or modify an existing Assistibe Technology (AT) service entry.
  
   
