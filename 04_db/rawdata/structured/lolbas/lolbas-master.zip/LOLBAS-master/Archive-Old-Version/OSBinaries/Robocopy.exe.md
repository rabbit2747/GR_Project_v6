## Robocopy.exe
* Functions: Copy
```

Robocopy.exe C:\SourceFolder C:\DestFolder
Copy the entire contents of the SourceFolder to the DestFolder.

Robocopy.exe \\SERVER\SourceFolder C:\DestFolder
Copy the entire contents of the SourceFolder to the DestFolder.
```
   
* Resources:   
  * https://social.technet.microsoft.com/wiki/contents/articles/1073.robocopy-and-a-few-examples.aspx
   
* Full path:   
  * c:\windows\system32\binary.exe
  * c:\windows\sysWOW64\binary.exe
   
* Notes: Thanks to Name of guy - @twitterhandle  
   
