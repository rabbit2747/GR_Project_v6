## Runscripthelper.exe
* Functions: Execute
```

runscripthelper.exe surfacecheck \\?\C:\Test\Microsoft\Diagnosis\scripts\test.txt C:\Test
Execute the PowerShell script named test.txt.
```
   
* Resources:   
  * https://posts.specterops.io/bypassing-application-whitelisting-with-runscripthelper-exe-1906923658fc
   
* Full path:   
  * C:\Windows\WinSxS\amd64_microsoft-windows-u..ed-telemetry-client_31bf3856ad364e35_10.0.16299.15_none_c2df1bba78111118\Runscripthelper.exe    
  * C:\Windows\WinSxS\amd64_microsoft-windows-u..ed-telemetry-client_31bf3856ad364e35_10.0.16299.192_none_ad4699b571e00c4a\Runscripthelper.exe     
   
* Notes: Thanks to Matt Graeber - @mattifestation  
   
