## Scriptrunner.exe
* Functions: Execute
```

Scriptrunner.exe -appvscript calc.exe
Execute calc.exe.

ScriptRunner.exe -appvscript "\\fileserver\calc.cmd"
Execute the calc.cmd script on the remote share.
```
   
* Resources:   
  * https://twitter.com/KyleHanslovan/status/914800377580503040
  * https://twitter.com/NickTyrer/status/914234924655312896
  * https://github.com/MoooKitty/Code-Execution
   
* Full path:   
  * c:\windows\system32\scriptrunner.exe
  * c:\windows\sysWOW64\scriptrunner.exe
   
* Notes: Thanks to Nick Tyrer - @NickTyrer  
   
