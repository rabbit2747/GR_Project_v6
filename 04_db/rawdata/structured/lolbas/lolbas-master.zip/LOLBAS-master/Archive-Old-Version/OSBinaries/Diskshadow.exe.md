## Diskshadow.exe
* Functions: Execute, Dump NTDS.dit
```

diskshadow.exe /s c:\test\diskshadow.txt
Execute commands using diskshadow.exe from a prepared diskshadow script.

diskshadow> exec calc.exe
Execute a calc.exe using diskshadow.exe.
```
   
* Resources:   
  * https://bohops.com/2018/03/26/diskshadow-the-return-of-vss-evasion-persistence-and-active-directory-database-extraction/
   
* Full path:   
  * c:\windows\system32\diskshadow.exe
  * c:\windows\sysWOW64\diskshadow.exe
   
* Notes: Thanks to Jimmy - @bohops  
   
