## Wscript.exe
* Functions: Execute, Read ADS
```

wscript c:\ads\file.txt:script.vbs
Executes the .VBS script stored as an Alternate Data Stream (ADS).
```
   
* Resources:   
  * ?
   
* Full path:   
  * c:\windows\system32\wscript.exe
  * c:\windows\sysWOW64\wscript.exe
   
* Notes: Thanks to ?  
   
