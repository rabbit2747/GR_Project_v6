## Register-cimprovider.exe
* Functions: Execute
```

Register-cimprovider -path "C:\folder\evil.dll"
Load the target .DLL.
```
   
* Resources:   
  * https://twitter.com/PhilipTsukerman/status/992021361106268161
   
* Full path:   
  * c:\windows\system32\Register-cimprovider.exe
  * c:\windows\sysWOW64\Register-cimprovider.exe
   
* Notes: Thanks to PhilipTsukerman - @PhilipTsukerman  
   
