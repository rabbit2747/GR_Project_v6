## Cmdkey.exe
* Functions: Credentials
```

cmdkey /list
List cached credentials.
```
   
* Resources:   
  * https://www.peew.pw/blog/2017/11/26/exploring-cmdkey-an-edge-case-for-privilege-escalation
   
* Full path:   
  * c:\windows\system32\cmdkey.exe
  * c:\windows\sysWOW64\cmdkey.exe
   
* Notes:   
   
