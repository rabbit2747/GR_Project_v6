## Extexport.exe
* Functions: Execute
```

Extexport.exe c:\test foo bar
Load a DLL located in the c:\\test folder with one of the following names: mozcrt19.dll, mozsqlite3.dll, or sqlite.dll
```
   
* Resources:   
  * http://www.hexacorn.com/blog/2018/04/24/extexport-yet-another-lolbin/
   
* Full path:   
  * C:\Program Files\Internet Explorer\Extexport.exe    
  * C:\Program Files\Internet Explorer(x86)\Extexport.exe
   
* Notes: Thanks to Adam - @hexacorn  
   
