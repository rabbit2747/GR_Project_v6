## Msconfig.exe
* Functions: Execute
```

Msconfig.exe -5
Executes command embeded in crafted c:\windows\system32\mscfgtlc.xml.
```
   
* Resources:   
  * https://twitter.com/pabraeken/status/991314564896690177
   
* Full path:   
  * c:\windows\system32\msconfig.exe
   
* Notes: Thanks to Pierre-Alexandre Braeken - @pabraeken
See the Payloads folder for an example mscfgtlc.xml file.
  
   
