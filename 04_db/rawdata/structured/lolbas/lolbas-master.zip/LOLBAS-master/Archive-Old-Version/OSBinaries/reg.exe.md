## reg.exe
* Functions: Export Reg, Add ADS, Import Reg
```

reg export HKLM\SOFTWARE\Microsoft\Evilreg c:\ads\file.txt:evilreg.reg
Export the target Registry key and save it to the specified .REG file.
```
   
* Resources:   
  * https://gist.github.com/api0cradle/cdd2d0d0ec9abb686f0e89306e277b8f
   
* Full path:   
  * c:\windows\system32\reg.exe
  * c:\windows\sysWOW64\reg.exe
   
* Notes: Thanks to Oddvar Moe - @oddvarmoe  
   
