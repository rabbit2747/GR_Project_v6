## testxlst.js
* Functions: Execute
```

cscript testxlst.js C:\test\test.xml c:\test\test.xls c:\test\test.out
Test Jscript included in Python tool to perform XSL transform (for payload execution).

wscript testxlst.js C:\test\test.xml c:\test\test.xls c:\test\test.out
Test Jscript included in Python tool to perform XSL transform (for payload execution).
```
   
* Resources:   
  * https://twitter.com/bohops/status/993314069116485632
   
* Full path:   
  * c:\python27amd64\Lib\site-packages\win32com\test\testxslt.js (Visual Studio Installation)
   
* Notes: Thanks to Jimmy - @bohops  
   
