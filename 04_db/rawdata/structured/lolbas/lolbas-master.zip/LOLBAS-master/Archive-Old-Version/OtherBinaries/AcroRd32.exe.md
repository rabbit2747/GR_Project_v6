## AcroRd32.exe
* Functions: Execute
```

Replace C:\Program Files (x86)\Adobe\Acrobat Reader DC\Reader\AcroCEF\RdrCEF.exe by your binary
Hijack RdrCEF.exe with a payload executable to launch when opening Adobe
```
   
* Resources:   
  * https://twitter.com/pabraeken/status/997997818362155008
   
* Full path:   
  * C:\Program Files (x86)\Adobe\Acrobat Reader DC\Reader\
   
* Notes: Thanks to Pierre-Alexandre Braeken - @pabraeken  
   
