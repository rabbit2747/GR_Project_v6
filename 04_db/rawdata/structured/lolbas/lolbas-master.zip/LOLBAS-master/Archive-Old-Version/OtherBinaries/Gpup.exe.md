## Gpup.exe
* Functions: Execute
```

Gpup.exe -w whatever -e c:\Windows\System32\calc.exe
Execute another command through gpup.exe (Notepad++ binary).
```
   
* Resources:   
  * https://twitter.com/pabraeken/status/997892519827558400
   
* Full path:   
  * C:\Program Files (x86)\Notepad++\updater\gpup.exe    
   
* Notes: Thanks to Pierre-Alexandre Braeken - @pabraeken  
   
