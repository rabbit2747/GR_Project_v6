## VBoxDrvInst.exe
* Functions: Persistence
```

VBoxDrvInst.exe driver executeinf c:\temp\calc.inf
Set registry key-value for persistance via INF file call through VBoxDrvInst.exe
```
   
* Resources:   
  * https://twitter.com/pabraeken/status/993497996179492864
   
* Full path:   
  * C:\Program Files\Oracle\VirtualBox Guest Additions
   
* Notes: Thanks to Pierre-Alexandre Braeken - @pabraeken  
   
