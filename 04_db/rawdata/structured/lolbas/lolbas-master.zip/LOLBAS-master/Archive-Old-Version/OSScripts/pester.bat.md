## pester.bat
* Functions: Execute code using Pester. The third parameter can be anything. The fourth is the payload.
```

Pester.bat [/help|?|-?|/?] "$null; notepad"
Execute notepad
```
   
* Resources:   
  * https://twitter.com/Oddvarmoe/status/993383596244258816
  * https://github.com/api0cradle/LOLBAS/blob/master/OSScripts/pester.md
   
* Full path:   
  * c:\Program Files\WindowsPowerShell\Modules\Pester\3.4.0\bin\Pester.bat
  * c:\Program Files\WindowsPowerShell\Modules\Pester\*\bin\Pester.bat
   
* Notes: Thanks to Emin Atac - @p0w3rsh3ll  
   
