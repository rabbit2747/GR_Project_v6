## Sqldumper.exe
* Functions: Dump process
```

sqldumper.exe 464 0 0x0110
Dump process by PID and create a dump file (Appears to create a dump file called SQLDmprXXXX.mdmp).

sqldumper.exe 540 0 0x01100:40
0x01100:40 flag will create a Mimikatz compatibile dump file.
```
   
* Resources:   
  * https://twitter.com/countuponsec/status/910969424215232518
  * https://twitter.com/countuponsec/status/910977826853068800
  * https://support.microsoft.com/en-us/help/917825/how-to-use-the-sqldumper-exe-utility-to-generate-a-dump-file-in-sql-se
   
* Full path:   
  * C:\Program Files\Microsoft SQL Server\90\Shared\SQLDumper.exe
  * C:\Program Files (x86)\Microsoft Office\root\vfs\ProgramFilesX86\Microsoft Analysis\AS OLEDB\140\SQLDumper.exe
   
* Notes: Thanks to Luis Rocha - @countuponsec  
   
