## rcsi.exe
* Functions: Execute
```

rcsi.exe bypass.csx
Use embedded C# within the csx script to execute the code.
```
   
* Resources:   
  * https://enigma0x3.net/2016/11/21/bypassing-application-whitelisting-by-using-rcsi-exe/
   
* Full path:   
  * 
   
* Notes: Thanks to Matt Nelson - @enigma0x3  
   
