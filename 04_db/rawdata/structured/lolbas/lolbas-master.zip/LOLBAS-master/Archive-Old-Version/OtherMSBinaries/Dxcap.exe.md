## Dxcap.exe
* Functions: Execute
```

Dxcap.exe -c C:\Windows\System32\notepad.exe
Launch notepad as a subprocess of Dxcap.exe
```
   
* Resources:   
  * https://twitter.com/harr0ey/status/992008180904419328
   
* Full path:   
  * c:\Windows\System32\dxcap.exe
  * c:\Windows\SysWOW64\dxcap.exe
   
* Notes: Thanks to Matt harr0ey - @harr0ey  
   
