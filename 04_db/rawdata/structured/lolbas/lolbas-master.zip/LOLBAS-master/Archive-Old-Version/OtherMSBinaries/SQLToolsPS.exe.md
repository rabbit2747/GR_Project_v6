## SQLToolsPS.exe
* Functions: Execute, evade logging
```

SQLToolsPS.exe -noprofile -command Start-Process calc.exe
Run PowerShell scripts and commands.
```
   
* Resources:   
  * https://twitter.com/pabraeken/status/993298228840992768
   
* Full path:   
  * C:\Program files (x86)\Microsoft SQL Server\130\Tools\Binn\sqlps.exe
   
* Notes: Thanks to Pierre-Alexandre Braeken - @pabraeken  
   
