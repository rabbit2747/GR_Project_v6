## Pcwutl.dll
* Functions: Execute
```

rundll32.exe pcwutl.dll,LaunchApplication calc.exe
Launch executable by calling the LaunchApplication function.
```
   
* Resources:   
  * https://twitter.com/harr0ey/status/989617817849876488
   
* Full path:   
  * c:\windows\system32\Pcwutl.dll
  * c:\windows\sysWOW64\Pcwutl.dll
   
* Notes: Thanks to Matt harr0ey - @harr0ey  
   
