## Mshtml.dll
* Functions: Execute
```

rundll32.exe Mshtml.dll,PrintHTML "C:\temp\calc.hta"
Invoke an HTML Application. Note - Pops a security warning and a print dialogue box.
```
   
* Resources:   
  * https://twitter.com/pabraeken/status/998567549670477824
   
* Full path:   
  * c:\windows\system32\Mshtml.dll
  * c:\windows\sysWOW64\Mshtml.dll
   
* Notes: Thanks to Pierre-Alexandre Braeken - @pabraeken  
   
