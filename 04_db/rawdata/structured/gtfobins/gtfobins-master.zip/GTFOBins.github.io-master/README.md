# GTFOBins

[![CI status](https://github.com/GTFOBins/GTFOBins.github.io/actions/workflows/ci.yml/badge.svg)](https://github.com/GTFOBins/GTFOBins.github.io/actions?query=workflow:CI)
[![CI status](https://github.com/GTFOBins/GTFOBins.github.io/actions/workflows/pages.yml/badge.svg)](https://github.com/GTFOBins/GTFOBins.github.io/actions?query=workflow:Pages)
[![Sponsor](https://img.shields.io/static/v1?label=Sponsor&message=%E2%9D%A4&color=%23db61a2)](https://github.com/sponsors/GTFOBins)

<a href="https://gtfobins.org"><img align="right" src="assets/logo.png" style="width: 100px" /></a>

GTFOBins is a curated list of Unix-like executables that can be used to bypass local security restrictions in misconfigured systems.

Find the project at: [gtfobins.org](https://gtfobins.org)
